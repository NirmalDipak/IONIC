import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the MusicdataProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class MusicdataProvider {

  private _musicdata: any = [];
  //get music data
  public getmusicdata(): any {
    return this._musicdata;
  }
  //set music data
  public setmusicdata(value: any) {
    this._musicdata = value;
  }

 }
