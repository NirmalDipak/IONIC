import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MusicplayPage } from './musicplay';

@NgModule({
  declarations: [
    MusicplayPage,
  ],
  imports: [
    IonicPageModule.forChild(MusicplayPage),
  ],
})
export class MusicplayPageModule {}
