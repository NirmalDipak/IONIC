import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FileChooser } from '@ionic-native/file-chooser';
import { File } from '@ionic-native/file';
import { NativeAudio } from '@ionic-native/native-audio';
import { Media, MediaObject } from '@ionic-native/media';
import {MusicdataProvider} from '../../providers/musicdata/musicdata'


/**
 * Generated class for the MusicplayPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-musicplay',
  templateUrl: 'musicplay.html',
})
export class MusicplayPage {
  audioarray: any;
  _fileList: any = [];

  constructor(public navCtrl: NavController, public navParams: NavParams,
    private nativeAudio: NativeAudio, private media: Media,public services:MusicdataProvider ,
    private file: File, private fileChooser: FileChooser) {
      this._fileList = services.getmusicdata();
      console.log("dgggddg..........",services.getmusicdata())
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MusicplayPage');
   // this.getMp3();
  }
  getMp3() {

    this.file.listDir(this.file.externalRootDirectory, '').then((result) => {

      for (let item of result) {
        if (item.isDirectory == true && item.name != '.' && item.name != '..') {
          this.getFileList(item.name);
        }
        else if (item.isFile == true) {
          this.saveFileToArray(item);
        }
      }
      //loading.dismiss().then(() => {
      //   console.log("data..............", JSON.stringify(this._fileList))
      // });
    },
      (error) => {
        console.log(error);
      });

  }
  saveFileToArray(item) {
    let extn = item.fullPath.split(".").pop();
    // console.log("called............................")
    if (extn == 'mp3' || extn == 'm4a') {
      console.log("mp3 found");
      this._fileList.push({
        name: item.name,
        path: item.fullPath
      })

      console.log("mp4....................", this._fileList)
    }
  }

  public getFileList(path: string): any {
    let file = new File();
    this.file.listDir(file.externalRootDirectory, path)
      .then((result) => {


        for (let item of result) {
          if (item.isDirectory == true && item.name != '.' && item.name != '..') {
            this.getFileList(path + '/' + item.name);
          }
          else {
            this.saveFileToArray(item);
          }
        }

      }, (error) => {
        console.log(error);
      })
  }

  play(track) {
    console.log("play call.......", track.path)
    const audioFile: MediaObject = this.media.create(track.path);
    audioFile.play();
  }
}
