import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ProgressBarComponent } from '../components/progress-bar/progress-bar';
import {SplashPage} from '../pages/splash/splash'
import { FileChooser } from '@ionic-native/file-chooser';
import { File } from '@ionic-native/file';
import {MusicplayPage} from '../pages/musicplay/musicplay';
import { NativeAudio } from '@ionic-native/native-audio';
import { Media, MediaObject } from '@ionic-native/media';
import { MusicdataProvider } from '../providers/musicdata/musicdata';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    MusicplayPage,
    ProgressBarComponent,
    SplashPage,
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    MusicplayPage,
    SplashPage,
  ],
  providers: [
    StatusBar,
    SplashScreen,
    FileChooser,
    NativeAudio,
    Media, 
    File,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    MusicdataProvider
  ]
})
export class AppModule {}
