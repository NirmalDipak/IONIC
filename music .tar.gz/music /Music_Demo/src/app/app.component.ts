import { Component } from '@angular/core';
import { Platform, ModalController, LoadingController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
import { SplashPage } from '../pages/splash/splash';
import { timer } from 'rxjs/observable/timer';
import { FileChooser } from '@ionic-native/file-chooser';
import { File } from '@ionic-native/file';
import {MusicplayPage} from '../pages/musicplay/musicplay';
import {MusicdataProvider} from '../providers/musicdata/musicdata'
import { Services } from '@angular/core/src/view';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  rootPage: any ;
  showSplash = true;
  nativepath: any;
  audioarray: any;
  _fileList: any = [];


  constructor(platform: Platform, statusBar: StatusBar,
    private file: File, public loadingCtrl: LoadingController,
    splashScreen: SplashScreen, modalCtrl: ModalController,public services:MusicdataProvider ,
    private fileChooser: FileChooser) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
     
      let splash = modalCtrl.create(SplashPage);
      splash.present();
      this.file.listDir(this.file.externalRootDirectory, '').then((result) => {
        //console.log("dir................",JSON.stringify(result))
      });
      this.getMp3().then(()=>{
        this.services.setmusicdata(this._fileList);
        this.rootPage = MusicplayPage;
      });

    });

  }


 async getMp3() {

    this.file.listDir(this.file.externalRootDirectory, '').then((result) => {
      let loading = this.loadingCtrl.create({
        content: 'Please wait...'
      });
      loading.present();
      for (let item of result) {
        if (item.isDirectory == true && item.name != '.' && item.name != '..') {
          this.getFileList(item.name);
        }
        else if (item.isFile == true) {
          this.saveFileToArray(item);
        }
      }
      loading.dismiss().then(() => {
        console.log("data..............", JSON.stringify(this._fileList))
      });
    },
      (error) => {
        console.log(error);
      });

  }
  saveFileToArray(item) {
    let extn = item.fullPath.split(".").pop();
    // console.log("called............................")
    if (extn == 'mp3' || extn == 'm4a') {
      console.log("mp3 found");
      this._fileList.push({
        name: item.name,
        path: item.fullPath,
        playing: false
      })
      
    
      console.log("mp4....................", this._fileList)
    }
  }

  public getFileList(path: string): any {
    let file = new File();
    this.file.listDir(file.externalRootDirectory, path)
      .then((result) => {
        for (let item of result) {
          if (item.isDirectory == true && item.name != '.' && item.name != '..') {
            this.getFileList(path + '/' + item.name);
          }
          else {
            this.saveFileToArray(item);
          }
        }
      }, (error) => {
        console.log(error);
      })
  }
}

