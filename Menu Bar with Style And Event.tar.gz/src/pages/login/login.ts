import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Events,ToastController, LoadingController, MenuController } from 'ionic-angular';
import { DashboardPage } from '../../pages/dashboard/dashboard';


@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  userID: string;
  password: string;

  constructor(public navCtrl: NavController,public events: Events, public navParams: NavParams, public menuCtrlr: MenuController, public loadingController: LoadingController, public toastCtrl: ToastController) {
    this.menuActive();
  }

  //Disable menu Swipe Option
  menuActive() {
    this.menuCtrlr.close();
    this.menuCtrlr.swipeEnable(false, 'menu');
  }

  //Use to Authenticate with api
  login() {

    const loading = this.loadingController.create({
      spinner: "bubbles",
      content: 'Please wait...'
    });
    loading.present();

    //Validation Of User Input in Client Side
    if (this.userID == null || this.password == null ||this.userID==""|| this.password == "") {
      let message = 'Please Enter Proper';
      console.log(this.userID,"pasww",this.password);
      if (this.userID == null||this.userID == "") {
        message = message + " user ID";
      }
      else {
        message = message + " Password";
      }
      const toast = this.toastCtrl.create({
        message: message,
        showCloseButton: true,
        position: 'top',
        duration: 2000,
      });
      loading.dismiss();
      toast.present();
    }
    
    else {
      loading.dismiss();
      this.events.publish('user:created',this.userID);
      this.navCtrl.setRoot(DashboardPage);
    }
  }


}
