import { Component,ViewChild } from '@angular/core';
import { Platform,Nav,Events } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { LoginPage } from '../pages/login/login';
import {DashboardPage } from '../pages/dashboard/dashboard';


@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = LoginPage;
  pages: Array<{ title: string, component: any }>;
  UserEmail: any;
  lgInit: any;


  constructor(platform: Platform,public events: Events, statusBar: StatusBar, splashScreen: SplashScreen) {
    events.subscribe('user:created', (userEventData) => {
      this.UserEmail = userEventData
      this.lgInit = userEventData.substring(0,2).toUpperCase();
      console.log("lginit subscriber data...",userEventData);
    });
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      splashScreen.hide();
      this.pages = [
        { title: 'Dashboard', component: DashboardPage },
      ];
    });
   
  }

  //Navigation For MenuBar
  openPage(page) {
    this.nav.setRoot(page.component);
  }

  //Sign Out 
  logout(){
    this.nav.setRoot(LoginPage);
    // alert("sjss");
    // this.rootPage = LoginPage;
  }

}

