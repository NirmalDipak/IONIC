import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { HTTP } from '@ionic-native/http';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  Email: any;
  Subject: any;
  constructor(public navCtrl: NavController, private http: HTTP) {

  }
  save() {
    if (this.Email !=null && this.Subject != null ) {
      let data = {
        'email': this.Email,
        'body': this.Subject
      }
      this.http.post('http://192.168.54.235:8001/api/sendmail', data, {})
        .then(data => {

          console.log(data.status);
          console.log(data.data); // data received by server
          console.log(data.headers);

        })
        .catch(error => {

          console.log(error.status);
          console.log(error.error); // error message as string
          console.log(error.headers);

        });
    }
    else {
      alert("Enter valid data");
    }
  }

}
