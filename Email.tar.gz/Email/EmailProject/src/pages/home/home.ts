import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController,private emailComposer: EmailComposer) {
    let email = {
      to: 'dipak.nirmal@multilinetech.in',
      cc: 'dipak.nirmal@multilinetech.in',
      bcc: [''],
      attachments: [ ],
      subject: 'Cordova Icons',
      body: 'How are you? Nice greetings from Leipzig',
      isHtml: true,
      app:'Gmail'
    }
    
    // Send a text message using default options
    try {
      
    } catch (error) {
      
    }
    this.emailComposer.open(email);
  }

}
