import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  searchTerm: any = "";
  jsonData: any;
  data: any;
  search :boolean = true;
  constructor(public navCtrl: NavController) {
    
    this.data = [
      { "id": 1, "label": "saw", "name": "Prithivi" },
      { "id": 2, "label": "saw1", "name": "Abimanyu" },
      { "id": 3, "label": "saw2", "name": "malliga" },
      { "id": 3, "label": "saw2", "name": "Gowdaman" },
      { "id": 3, "label": "saw2", "name": "Neethi" },
      { "id": 3, "label": "saw2", "name": "abirami1" },
      { "id": 3, "label": "saw2", "name": "Preeti" },
      { "id": 3, "label": "saw2", "name": "Neha" },
      { "id": 3, "label": "saw2", "name": "Lokesh" },
      { "id": 3, "label": "saw2", "name": "Deepak" },
      { "id": 3, "label": "saw2", "name": "Ritu" },
      { "id": 3, "label": "saw2", "name": "malliga" }

    ];

    this.jsonData = this.data;
  }

  setFilteredItems() {
    this.search =true;
    this.jsonData = this.filterItems(this.searchTerm);

  }
  setsearch(){
    this.search =true;
  }
  filterItems(searchTerm) {
    return this.data.filter((item) => {
      return item.name.toLowerCase().includes(searchTerm.toLowerCase());
    });

  }
}
